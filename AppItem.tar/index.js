import './index.css'

const AppItem = props => {
  const {projectDetails} = props
  const {description} = projectDetails
  return (
    <>
      <li className="project-item-container">
        <div className="project-item-details-container">
          <p className="project-item-description">{description}</p>
        </div>
      </li>
    </>
  )
}

export default AppItem
