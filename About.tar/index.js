import {Component} from 'react'

import TabItem from '../TabItem'

import AppItem from '../AppItem'

import './index.css'

const tabsList = [
  {tabId: 'STATIC', displayText: 'Our Mission'},
  {tabId: 'RESPONSIVE', displayText: 'Our Vision'},
  {tabId: 'DYNAMIC', displayText: 'Our Value'},
]

const projectsList = [
  {
    projectId: 0,
    category: 'STATIC',
    description:
      'An IT firm or MSP who keeps your IT running smoothly at all times.',
  },
  {
    projectId: 1,
    category: 'RESPONSIVE',

    description:
      'many IT firms struggle to keep themselves and their IT from falling apart.',
  },
  {
    projectId: 2,
    category: 'DYNAMIC',
    description:
      'We raised the standards in this industry and are a leading cybersecurity',
  },
]

class About extends Component {
  state = {
    activeTabId: tabsList[0].tabId,
  }

  getProjects = () => {
    const {activeTabId} = this.state
    const filteredProjects = projectsList.filter(
      eachProjectDetails => eachProjectDetails.category === activeTabId,
    )
    return filteredProjects
  }

  updateActiveTabId = tabId => {
    this.setState({activeTabId: tabId})
  }

  render() {
    const {activeTabId} = this.state
    const filteredProjects = this.getProjects()
    return (
      <div className="about-container">
        <div className="car">
          <h1>
            Choose<span className="span">The Best</span> IT <br />
            Service Company
          </h1>
          <img
            src="https://assets.ccbp.in/frontend/react-js/about-blog-img.png"
            alt="about"
            className="im"
          />
        </div>
        <p>
          IT Soft has been optimized to give your visitors the best <br />
          experience in terms of UX/UI,with a unique design.
        </p>
        <ul className="tabs-container">
          {tabsList.map(tabDetails => (
            <TabItem
              key={tabDetails.tabId}
              tabDetails={tabDetails}
              updateActiveTabId={this.updateActiveTabId}
              isActive={activeTabId === tabDetails.tabId}
            />
          ))}
        </ul>

        <ul className="project-list-container">
          {filteredProjects.map(projectDetails => (
            <AppItem
              key={projectDetails.projectId}
              projectDetails={projectDetails}
            />
          ))}
        </ul>
      </div>
    )
  }
}

export default About
