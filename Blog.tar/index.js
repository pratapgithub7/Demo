import './index.css'

const Blog = () => (
  <div className="con">
    <img
      src="https://assets.ccbp.in/frontend/react-js/failure-img.png "
      alt="contact"
      className="contact-img"
    />
    <h1 className="contact-heading">Blog</h1>
  </div>
)

export default Blog
