import './index.css'

const Home = () => (
  <div className="home-container">
    <div className="container">
      <h1>
        Best <span className="it"> IT Solution</span> <br />
        Company Market
      </h1>
      <img
        src="https://assets.ccbp.in/frontend/react-js/nxt-watch-failure-view-dark-theme-img.png"
        alt="on"
        className="img"
      />
    </div>
    <p>
      Technology Services Provider Built for.Your Unique Needs.
      <br />
      We help position your business for future innovation.
    </p>
    <div className="container">
      <div className="card">
        <p>
          Professional <br />
          Services
        </p>
      </div>
      <div className="card">
        <p>
          Managed IT <br />
          Solution
        </p>
      </div>
      <div className="card">
        <p>
          Cyber&IT <br />
          Security
        </p>
      </div>
    </div>
  </div>
)

export default Home
