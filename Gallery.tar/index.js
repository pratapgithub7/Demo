import './index.css'

const Gallery = () => (
  <div className="con">
    <img
      src="https://assets.ccbp.in/frontend/react-js/jobby-app-not-found-img.png  "
      alt="contact"
      className="contact-img"
    />
    <h1 className="contact-heading">Gallery</h1>
  </div>
)

export default Gallery
