import './index.css'

const Team = () => (
  <div className="con">
    <img
      src="https://assets.ccbp.in/frontend/react-js/appointments-app/appointments-img.png "
      alt="contact"
      className="contact-img"
    />
    <h1 className="contact-heading">Team Work</h1>
  </div>
)

export default Team
